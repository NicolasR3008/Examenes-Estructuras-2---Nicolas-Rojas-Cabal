//Nicolas Rojas Cabal - 2226088


export default class Cola {
    constructor() {
      this.elementos = [];
    }
  
    encolar(elemento) {
      this.elementos.push(elemento);
    }
  
    verTodos() {
      return this.elementos;
    }
  }