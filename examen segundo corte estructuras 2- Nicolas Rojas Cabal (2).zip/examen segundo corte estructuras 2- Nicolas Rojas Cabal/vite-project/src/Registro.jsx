//Nicolas Rojas Cabal - 2226088


import { useState } from 'react';
import Cola from './Cola';
import Pila from './Pila';
import './Registro.css';

export const Registro = ({ clientes, setClientes }) => {
  const [nombre, setNombre] = useState('');
  const [tipo, setTipo] = useState('consulta');
  const [mensaje, setMensaje] = useState('');

  const manejarEnvio = (e) => {
    e.preventDefault();
    if (!nombre || !mensaje) return alert('¡Completa todos los campos!');

    const nuevosClientes = [...clientes];
    let cliente = nuevosClientes.find(c => c.nombre === nombre);

    if (!cliente) {
      cliente = { nombre, consultas: new Cola(), reclamos: new Pila() };
      nuevosClientes.push(cliente);
    }

    tipo === 'consulta' 
      ? cliente.consultas.encolar(mensaje) 
      : cliente.reclamos.apilar(mensaje);

    setClientes(nuevosClientes);
    setNombre('');
    setMensaje('');
  };

  return (
    <div className="registro-container">
      <h2 className="registro-title">Registro</h2>
      <form onSubmit={manejarEnvio}>
        <input
          className="registro-input"
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        
        <div className="radio-group">
          <label>
            <input
              type="radio"
              checked={tipo === 'consulta'}
              onChange={() => setTipo('consulta')}
            /> Consulta
          </label>
          <label>
            <input
              type="radio"
              checked={tipo === 'reclamo'}
              onChange={() => setTipo('reclamo')}
            /> Reclamo
          </label>
        </div>

        <textarea
          className="registro-textarea"
          placeholder="Mensaje"
          value={mensaje}
          onChange={(e) => setMensaje(e.target.value)}
        />

        <button className="registro-button">Guardar</button>
      </form>
    </div>
  );
};