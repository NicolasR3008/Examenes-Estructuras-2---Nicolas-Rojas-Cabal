//Nicolas Rojas Cabal - 2226088


import { useState } from 'react';
import './Informacion.css';

export const Informacion = ({ clientes }) => {
  const [busqueda, setBusqueda] = useState('');
  const [cliente, setCliente] = useState(null);

  const buscar = () => {
    const encontrado = clientes.find(c => 
      c.nombre.toLowerCase().includes(busqueda.toLowerCase().trim())
    );
    setCliente(encontrado);
  };

  return (
    <div className="info-container">
      <h2 className="info-title">Historial</h2>
      <div className="buscador-container">
        <input
          className="info-input"
          placeholder="Buscar cliente"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
        <button className="info-button" onClick={buscar}>Buscar</button>
      </div>

      {cliente && (
        <div className="resultado-container">
          <h3 className="cliente-nombre">{cliente.nombre}</h3>
          
          <div className="seccion-consultas">
            <h4>Consultas:</h4>
            {cliente.consultas.verTodos().map((c, i) => (
              <p key={i}>→ {c}</p>
            ))}
          </div>

          <div className="seccion-reclamos">
            <h4>Reclamos:</h4>
            {cliente.reclamos.verTodos().map((r, i) => (
              <p key={i}>→ {r}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};