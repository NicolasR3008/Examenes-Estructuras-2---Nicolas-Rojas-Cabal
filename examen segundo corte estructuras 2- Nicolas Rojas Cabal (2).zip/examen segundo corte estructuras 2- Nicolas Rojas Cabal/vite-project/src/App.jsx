//Nicolas Rojas Cabal - 2226088

import { useState } from 'react';
import { Registro } from './Registro';
import { Informacion } from './Informacion';
import './App.css';

export default function App() {
  const [clientes, setClientes] = useState([]);

  return (
    <div className="app-container">
      <h1 className="app-title">Centro de Atención</h1>
      <Registro clientes={clientes} setClientes={setClientes} />
      <Informacion clientes={clientes} />
    </div>
  );
}

