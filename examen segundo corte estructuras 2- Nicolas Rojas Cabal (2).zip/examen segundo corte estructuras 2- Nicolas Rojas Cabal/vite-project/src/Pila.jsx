//Nicolas Rojas Cabal - 2226088


export default class Pila {
    constructor() {
      this.elementos = [];
    }
  
    apilar(elemento) {
      this.elementos.push(elemento);
    }
  
    verTodos() {
      return [...this.elementos].reverse();
    }
  }



  