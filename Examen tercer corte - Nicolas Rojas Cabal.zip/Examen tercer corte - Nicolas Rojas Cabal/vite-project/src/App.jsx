//Nicolas rojas Cabal- 2226088


"use client"

import { CiudadesProvider } from "./context/CiudadesContext"
import AppContent from "./components/AppContent"
import "./App.css"

function App() {
  return (
    <CiudadesProvider>
      <AppContent />
    </CiudadesProvider>
  )
}

export default App
