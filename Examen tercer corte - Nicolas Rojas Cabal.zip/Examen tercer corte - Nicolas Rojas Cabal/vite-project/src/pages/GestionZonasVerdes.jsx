//Nicolas rojas Cabal- 2226088


"use client"

import { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { seleccionarCiudad, agregarZonaVerde } from "../store/ciudadesSlice"

const GestionZonasVerdes = () => {
  const [nombreZona, setNombreZona] = useState("")
  const [zonaParent, setZonaParent] = useState("")
  const [ciudadElegida, setCiudadElegida] = useState("")

  const dispatch = useDispatch()
  const { grafo, arboles, ciudadSeleccionada } = useSelector((state) => state.ciudades)

  const handleSeleccionarCiudad = (e) => {
    const ciudad = e.target.value
    setCiudadElegida(ciudad)
    dispatch(seleccionarCiudad(ciudad))
  }

  const handleAgregarZona = (e) => {
    e.preventDefault()
    if (ciudadSeleccionada && nombreZona.trim()) {
      dispatch(
        agregarZonaVerde({
          ciudad: ciudadSeleccionada,
          zonaParent,
          nombreZona,
        }),
      )
      setNombreZona("")
      setZonaParent("")
    }
  }

  const obtenerZonas = (ciudad) => {
    if (!arboles[ciudad]) return []

    const arbol = arboles[ciudad]
    const lista = []

    const recolectar = (nodo = arbol.raiz, prefijo = "") => {
      lista.push({ nombre: nodo.nombre, ruta: prefijo + nodo.nombre })
      nodo.hijos.forEach((hijo) => {
        recolectar(hijo, prefijo + nodo.nombre + " > ")
      })
    }

    recolectar()
    return lista
  }

  const renderArbol = (ciudad) => {
    if (!arboles[ciudad]) return null

    const arbol = arboles[ciudad]

    const renderNodo = (nodo, nivel = 0) => (
      <div key={nodo.nombre} style={{ marginLeft: `${nivel * 20}px`, marginBottom: "5px" }}>
        <div
          style={{
            padding: "5px 10px",
            background: "#e8f4e8",
            borderRadius: "4px",
            display: "inline-block",
          }}
        >
          {nodo.nombre}
        </div>
        {nodo.hijos.map((hijo) => renderNodo(hijo, nivel + 1))}
      </div>
    )

    return renderNodo(arbol.raiz)
  }

  const calcularEstadisticas = (ciudad) => {
    if (!arboles[ciudad]) return { profundidad: 0, totalZonas: 0 }

    const arbol = arboles[ciudad]
    return {
      profundidad: arbol.calcularProfundidad(),
      totalZonas: arbol.contarZonasVerdes(),
    }
  }

  return (
    <div>
      <h2>Gestión de Zonas Verdes</h2>

      <div className="seccion">
        <h3>Seleccionar Ciudad</h3>
        <select
          value={ciudadElegida}
          onChange={handleSeleccionarCiudad}
          style={{ padding: "8px", width: "100%", marginBottom: "20px" }}
        >
          <option value="">Seleccione una ciudad</option>
          {grafo.obtenerCiudades().map((ciudad) => (
            <option key={ciudad} value={ciudad}>
              {ciudad}
            </option>
          ))}
        </select>
      </div>

      {ciudadSeleccionada && (
        <>
          <div className="seccion">
            <h3>Estadísticas de {ciudadSeleccionada}</h3>
            <div style={{ display: "flex", gap: "20px", marginTop: "15px" }}>
              <div
                style={{
                  flex: 1,
                  padding: "15px",
                  background: "white",
                  borderRadius: "8px",
                  textAlign: "center",
                  boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                }}
              >
                <h4>Profundidad</h4>
                <p style={{ fontSize: "2rem", fontWeight: "bold", color: "#4caf50" }}>
                  {calcularEstadisticas(ciudadSeleccionada).profundidad}
                </p>
              </div>
              <div
                style={{
                  flex: 1,
                  padding: "15px",
                  background: "white",
                  borderRadius: "8px",
                  textAlign: "center",
                  boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                }}
              >
                <h4>Total Zonas</h4>
                <p style={{ fontSize: "2rem", fontWeight: "bold", color: "#4caf50" }}>
                  {calcularEstadisticas(ciudadSeleccionada).totalZonas}
                </p>
              </div>
            </div>
          </div>

          <div className="seccion">
            <h3>Agregar Zona Verde</h3>
            <form onSubmit={handleAgregarZona} className="formulario">
              <input
                type="text"
                placeholder="Nombre de la zona"
                value={nombreZona}
                onChange={(e) => setNombreZona(e.target.value)}
              />
              <select value={zonaParent} onChange={(e) => setZonaParent(e.target.value)}>
                <option value="">Zona Principal</option>
                {obtenerZonas(ciudadSeleccionada).map((zona) => (
                  <option key={zona.ruta} value={zona.nombre}>
                    {zona.ruta}
                  </option>
                ))}
              </select>
              <button type="submit" className="btn">
                Agregar Zona
              </button>
            </form>
          </div>

          <div className="seccion">
            <h3>Estructura de Zonas Verdes</h3>
            <div
              style={{
                padding: "15px",
                background: "white",
                borderRadius: "8px",
                marginTop: "15px",
                boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
              }}
            >
              {renderArbol(ciudadSeleccionada)}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default GestionZonasVerdes
