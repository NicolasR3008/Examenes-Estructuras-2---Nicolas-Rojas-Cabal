//Nicolas rojas Cabal- 2226088


"use client"

import { useRef, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { seleccionarCiudad } from "../store/ciudadesSlice"

const VisualizacionGrafo = () => {
  const canvasRef = useRef(null)
  const dispatch = useDispatch()
  const { grafo, ciudadSeleccionada } = useSelector((state) => state.ciudades)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    const ciudades = grafo.obtenerCiudades()
    const width = canvas.width
    const height = canvas.height

    ctx.clearRect(0, 0, width, height)

    const posiciones = {}
    const radio = 30
    const centroX = width / 2
    const centroY = height / 2
    const radioCirculo = Math.min(width, height) / 2 - radio - 30

    ciudades.forEach((ciudad, index) => {
      const angulo = (index / ciudades.length) * 2 * Math.PI
      const x = centroX + radioCirculo * Math.cos(angulo)
      const y = centroY + radioCirculo * Math.sin(angulo)
      posiciones[ciudad] = { x, y }
    })

    ciudades.forEach((ciudad) => {
      const conexiones = grafo.obtenerConexiones(ciudad)
      const pos1 = posiciones[ciudad]

      conexiones.forEach((ciudadConectada) => {
        const pos2 = posiciones[ciudadConectada]
        if (pos2) {
          ctx.strokeStyle = "#666"
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.moveTo(pos1.x, pos1.y)
          ctx.lineTo(pos2.x, pos2.y)
          ctx.stroke()
        }
      })
    })

    ciudades.forEach((ciudad) => {
      const { x, y } = posiciones[ciudad]

      ctx.beginPath()
      ctx.arc(x, y, radio, 0, 2 * Math.PI)

      if (ciudad === ciudadSeleccionada) {
        ctx.fillStyle = "#4caf50"
      } else {
        ctx.fillStyle = "#2196f3"
      }

      ctx.fill()
      ctx.strokeStyle = "#333"
      ctx.lineWidth = 2
      ctx.stroke()

      ctx.fillStyle = "white"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.font = "14px Arial"
      ctx.fillText(ciudad, x, y)
    })

    const handleClick = (e) => {
      const rect = canvas.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      ciudades.forEach((ciudad) => {
        const pos = posiciones[ciudad]
        const distancia = Math.sqrt((pos.x - x) ** 2 + (pos.y - y) ** 2)
        if (distancia <= radio) {
          dispatch(seleccionarCiudad(ciudad))
        }
      })
    }

    canvas.addEventListener("click", handleClick)
    return () => canvas.removeEventListener("click", handleClick)
  }, [grafo, ciudadSeleccionada, dispatch])

  return (
    <div>
      <h2>Gestión del Grafo</h2>
      <p>Haz clic en una ciudad para seleccionarla</p>

      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <canvas
          ref={canvasRef}
          width={600}
          height={400}
          style={{
            border: "1px solid #ddd",
            borderRadius: "8px",
            background: "white",
          }}
        />
      </div>

      {ciudadSeleccionada && (
        <div style={{ textAlign: "center", marginTop: "20px" }}>
          <p>
            Ciudad seleccionada: <strong>{ciudadSeleccionada}</strong>
          </p>
        </div>
      )}
    </div>
  )
}

export default VisualizacionGrafo
