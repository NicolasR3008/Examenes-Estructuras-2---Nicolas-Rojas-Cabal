//Nicolas rojas Cabal- 2226088


"use client"

import { useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { agregarCiudad, eliminarCiudad, conectarCiudades, deshacerAccion } from "../store/ciudadesSlice"

const GestionCiudades = () => {
  const [nombreCiudad, setNombreCiudad] = useState("")
  const [ciudad1, setCiudad1] = useState("")
  const [ciudad2, setCiudad2] = useState("")

  const dispatch = useDispatch()
  const { grafo, historialAcciones } = useSelector((state) => state.ciudades)

  const handleAgregarCiudad = (e) => {
    e.preventDefault()
    if (nombreCiudad.trim()) {
      dispatch(agregarCiudad(nombreCiudad))
      setNombreCiudad("")
    }
  }

  const handleConectarCiudades = (e) => {
    e.preventDefault()
    if (ciudad1 && ciudad2 && ciudad1 !== ciudad2) {
      dispatch(conectarCiudades({ ciudad1, ciudad2 }))
      setCiudad1("")
      setCiudad2("")
    }
  }

  const handleDeshacer = () => {
    dispatch(deshacerAccion())
  }

  return (
    <div>
      <h2>Gestión de Ciudades</h2>

      <div className="seccion">
        <h3>Agregar Ciudad</h3>
        <form onSubmit={handleAgregarCiudad} className="formulario">
          <input
            type="text"
            placeholder="Nombre de la ciudad"
            value={nombreCiudad}
            onChange={(e) => setNombreCiudad(e.target.value)}
          />
          <button type="submit" className="btn">
            Agregar Ciudad
          </button>
        </form>
      </div>

      <div className="seccion">
        <h3>Conectar Ciudades</h3>
        <form onSubmit={handleConectarCiudades} className="formulario">
          <select value={ciudad1} onChange={(e) => setCiudad1(e.target.value)}>
            <option value="">Seleccione ciudad 1</option>
            {grafo.obtenerCiudades().map((ciudad) => (
              <option key={ciudad} value={ciudad}>
                {ciudad}
              </option>
            ))}
          </select>
          <select value={ciudad2} onChange={(e) => setCiudad2(e.target.value)}>
            <option value="">Seleccione ciudad 2</option>
            {grafo.obtenerCiudades().map((ciudad) => (
              <option key={ciudad} value={ciudad}>
                {ciudad}
              </option>
            ))}
          </select>
          <button type="submit" className="btn">
            Conectar
          </button>
        </form>
      </div>

      <div className="seccion">
        <h3>Ciudades en la Red</h3>
        <ul>
          {grafo.obtenerCiudades().map((ciudad) => (
            <li key={ciudad} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0" }}>
              <span>{ciudad}</span>
              <button onClick={() => dispatch(eliminarCiudad(ciudad))} className="btn btn-eliminar">
                Eliminar
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div className="historial">
        <h3>Historial de Acciones</h3>
        {historialAcciones.isEmpty() ? (
          <p>No hay acciones registradas</p>
        ) : (
          <>
            <ul>
              {historialAcciones.items.map((accion, index) => (
                <li key={index}>
                  {accion.tipo === "AGREGAR_CIUDAD" && `Agregar ciudad: ${accion.ciudad}`}
                  {accion.tipo === "ELIMINAR_CIUDAD" && `Eliminar ciudad: ${accion.ciudad}`}
                  {accion.tipo === "CONECTAR_CIUDADES" && `Conectar: ${accion.ciudad1} - ${accion.ciudad2}`}
                  {accion.tipo === "AGREGAR_ZONA" && `Agregar zona: ${accion.nombreZona} en ${accion.ciudad}`}
                </li>
              ))}
            </ul>
            <button onClick={handleDeshacer} className="btn" style={{ marginTop: "10px" }}>
              Deshacer última acción
            </button>
          </>
        )}
      </div>
    </div>
  )
}

export default GestionCiudades
