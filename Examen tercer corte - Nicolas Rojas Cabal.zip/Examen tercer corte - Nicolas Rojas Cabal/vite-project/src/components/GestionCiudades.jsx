//Nicolas rojas Cabal- 2226088


"use client"

import { useState } from "react"
import { useCiudades } from "../context/CiudadesContext"
import styles from "./ComponentesEstilos.module.css"

const GestionCiudades = () => {
  const [nombreCiudad, setNombreCiudad] = useState("")
  const [ciudad1, setCiudad1] = useState("")
  const [ciudad2, setCiudad2] = useState("")
  const [ciudadDesconectar1, setCiudadDesconectar1] = useState("")
  const [ciudadDesconectar2, setCiudadDesconectar2] = useState("")

  const { grafo, agregarCiudad, eliminarCiudad, conectarCiudades, desconectarCiudades } = useCiudades()

  const handleAgregarCiudad = (e) => {
    e.preventDefault()
    if (nombreCiudad.trim()) {
      agregarCiudad(nombreCiudad)
      setNombreCiudad("")
    }
  }

  const handleConectarCiudades = (e) => {
    e.preventDefault()
    if (ciudad1 && ciudad2 && ciudad1 !== ciudad2) {
      conectarCiudades(ciudad1, ciudad2)
      setCiudad1("")
      setCiudad2("")
    }
  }

  const handleDesconectarCiudades = (e) => {
    e.preventDefault()
    if (ciudadDesconectar1 && ciudadDesconectar2 && ciudadDesconectar1 !== ciudadDesconectar2) {
      desconectarCiudades(ciudadDesconectar1, ciudadDesconectar2)
      setCiudadDesconectar1("")
      setCiudadDesconectar2("")
    }
  }

  return (
    <div className={styles.gestionContainer}>
      <h2>Gestión de Ciudades</h2>

      <div className="seccion">
        <h3>Agregar Ciudad</h3>
        <form onSubmit={handleAgregarCiudad} className="formulario">
          <div className="form-group">
            <label>Nombre de la Ciudad:</label>
            <input
              type="text"
              placeholder="Ingrese nombre de ciudad"
              value={nombreCiudad}
              onChange={(e) => setNombreCiudad(e.target.value)}
            />
          </div>
          <button type="submit" className="btn">
            Agregar Ciudad
          </button>
        </form>
      </div>

      <div className="seccion">
        <h3>Conectar Ciudades</h3>
        <form onSubmit={handleConectarCiudades} className="formulario">
          <div className="form-group">
            <label>Conectar Ciudades:</label>
            <select value={ciudad1} onChange={(e) => setCiudad1(e.target.value)}>
              <option value="">Seleccione ciudad 1</option>
              {grafo.obtenerCiudades().map((ciudad) => (
                <option key={ciudad} value={ciudad}>
                  {ciudad}
                </option>
              ))}
            </select>
            <select value={ciudad2} onChange={(e) => setCiudad2(e.target.value)}>
              <option value="">Seleccione ciudad 2</option>
              {grafo.obtenerCiudades().map((ciudad) => (
                <option key={ciudad} value={ciudad}>
                  {ciudad}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn">
            Conectar
          </button>
        </form>
      </div>

      <div className="seccion">
        <h3>Desconectar Ciudades</h3>
        <form onSubmit={handleDesconectarCiudades} className="formulario">
          <div className="form-group">
            <label>Desconectar Ciudades:</label>
            <select value={ciudadDesconectar1} onChange={(e) => setCiudadDesconectar1(e.target.value)}>
              <option value="">Seleccione ciudad 1</option>
              {grafo.obtenerCiudades().map((ciudad) => (
                <option key={ciudad} value={ciudad}>
                  {ciudad}
                </option>
              ))}
            </select>
            <select value={ciudadDesconectar2} onChange={(e) => setCiudadDesconectar2(e.target.value)}>
              <option value="">Seleccione ciudad 2</option>
              {grafo.obtenerCiudades().map((ciudad) => (
                <option key={ciudad} value={ciudad}>
                  {ciudad}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className="btn">
            Desconectar
          </button>
        </form>
      </div>

      <div className="seccion">
        <h3>Ciudades en la Red</h3>
        <div className="lista-ciudades">
          <ul>
            {grafo.obtenerCiudades().map((ciudad) => (
              <li key={ciudad} className="ciudad-item">
                <span>{ciudad}</span>
                <button onClick={() => eliminarCiudad(ciudad)} className="btn btn-eliminar">
                  Eliminar
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}

export default GestionCiudades
