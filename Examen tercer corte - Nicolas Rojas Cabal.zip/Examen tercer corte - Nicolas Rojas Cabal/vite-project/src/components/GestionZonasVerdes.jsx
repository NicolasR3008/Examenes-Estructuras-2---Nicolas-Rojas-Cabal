//Nicolas rojas Cabal- 2226088


"use client"

import { useState } from "react"
import { useCiudades } from "../context/CiudadesContext"
import styles from "./ComponentesEstilos.module.css"

const GestionZonasVerdes = () => {
  const [nombreZona, setNombreZona] = useState("")
  const [zonaParent, setZonaParent] = useState("")
  const [ciudadElegida, setCiudadElegida] = useState("")
  const [nuevaZonaPadre, setNuevaZonaPadre] = useState("")

  const {
    grafo,
    arboles,
    ciudadSeleccionada,
    seleccionarCiudad,
    agregarZonaPadre,
    agregarZonaVerde,
    calcularEstadisticas,
  } = useCiudades()

  const handleSeleccionarCiudad = (e) => {
    const ciudad = e.target.value
    setCiudadElegida(ciudad)
    seleccionarCiudad(ciudad)
  }

  const handleAgregarZona = (e) => {
    e.preventDefault()
    if (ciudadSeleccionada && nombreZona.trim()) {
      agregarZonaVerde(ciudadSeleccionada, zonaParent, nombreZona)
      setNombreZona("")
      setZonaParent("")
    }
  }

  const handleAgregarZonaPadre = (e) => {
    e.preventDefault()
    if (ciudadSeleccionada && nuevaZonaPadre.trim()) {
      agregarZonaPadre(ciudadSeleccionada, nuevaZonaPadre)
      setNuevaZonaPadre("")
    }
  }

  const obtenerZonas = (ciudad) => {
    const lista = []
    const zonasVistas = new Set()

    for (const clave in arboles) {
      if (clave === ciudad || clave.startsWith(ciudad + "_")) {
        const arbol = arboles[clave]

        const recolectar = (nodo = arbol.raiz, prefijo = "") => {
          const ruta = prefijo + nodo.nombre
          if (!zonasVistas.has(ruta)) {
            zonasVistas.add(ruta)
            lista.push({ nombre: nodo.nombre, ruta })
          }

          nodo.hijos.forEach((hijo) => {
            recolectar(hijo, prefijo + nodo.nombre + " > ")
          })
        }

        recolectar()
      }
    }

    return lista
  }

  const renderArbol = (ciudad) => {
    const arbolesCiudad = []

    for (const clave in arboles) {
      if (clave === ciudad || clave.startsWith(ciudad + "_")) {
        const arbol = arboles[clave]
        arbolesCiudad.push(arbol)
      }
    }

    const renderNodo = (nodo, nivel = 0) => (
      <div key={nodo.nombre} style={{ marginLeft: `${nivel * 20}px`, marginBottom: "5px" }}>
        <div
          style={{
            padding: "5px 10px",
            background: "#e8f4e8",
            borderRadius: "4px",
            display: "inline-block",
          }}
        >
          {nodo.nombre}
        </div>
        {nodo.hijos.map((hijo) => renderNodo(hijo, nivel + 1))}
      </div>
    )

    return (
      <div>
        {arbolesCiudad.map((arbol, index) => (
          <div key={index} style={{ marginBottom: "15px" }}>
            {renderNodo(arbol.raiz)}
          </div>
        ))}
      </div>
    )
  }

  if (!ciudadSeleccionada) {
    return (
      <div className={styles.gestionContainer}>
        <h2>Gestión de Zonas Verdes</h2>

        <div className={styles.seccion}>
          <h3>Seleccionar Ciudad</h3>
          <select
            value={ciudadElegida}
            onChange={handleSeleccionarCiudad}
            style={{ padding: "8px", width: "100%", marginBottom: "20px" }}
          >
            <option value="">Seleccione una ciudad</option>
            {grafo.obtenerCiudades().map((ciudad) => (
              <option key={ciudad} value={ciudad}>
                {ciudad}
              </option>
            ))}
          </select>
        </div>

        <div className={styles.noSeleccionada}>
          <p>Selecciona una ciudad para gestionar sus zonas verdes</p>
        </div>
      </div>
    )
  }

  const estadisticas = calcularEstadisticas(ciudadSeleccionada)

  return (
    <div className={styles.gestionContainer}>
      <h2>Gestión de Zonas Verdes - {ciudadSeleccionada}</h2>

      <div className={styles.seccion}>
        <h3>Seleccionar Ciudad</h3>
        <select
          value={ciudadElegida}
          onChange={handleSeleccionarCiudad}
          style={{ padding: "8px", width: "100%", marginBottom: "20px" }}
        >
          <option value="">Seleccione una ciudad</option>
          {grafo.obtenerCiudades().map((ciudad) => (
            <option key={ciudad} value={ciudad}>
              {ciudad}
            </option>
          ))}
        </select>
      </div>

      <div className={styles.seccion}>
        <h3>Estadísticas de {ciudadSeleccionada}</h3>
        <div className={styles.estadisticas}>
          <div className={styles.estadistica}>
            <h4>Profundidad</h4>
            <p className={styles.valor}>{estadisticas.profundidad}</p>
          </div>
          <div className={styles.estadistica}>
            <h4>Total Zonas</h4>
            <p className={styles.valor}>{estadisticas.totalZonas}</p>
          </div>
        </div>
      </div>

      <div className={styles.seccion}>
        <h3>Agregar Zona Padre</h3>
        <form onSubmit={handleAgregarZonaPadre} className={styles.formulario}>
          <div className={styles.formGroup}>
            <label>Nombre de la nueva zona padre:</label>
            <input
              type="text"
              placeholder="Ej: Parque Central, Zona Deportiva"
              value={nuevaZonaPadre}
              onChange={(e) => setNuevaZonaPadre(e.target.value)}
            />
          </div>
          <button type="submit" className={styles.btn}>
            Agregar Zona Padre
          </button>
        </form>
      </div>

      <div className={styles.seccion}>
        <h3>Agregar Subzona</h3>
        <form onSubmit={handleAgregarZona} className={styles.formulario}>
          <div className={styles.formGroup}>
            <label>Nombre de la zona:</label>
            <input
              type="text"
              placeholder="Nombre de la zona"
              value={nombreZona}
              onChange={(e) => setNombreZona(e.target.value)}
            />
          </div>
          <div className={styles.formGroup}>
            <label>Zona padre:</label>
            <select value={zonaParent} onChange={(e) => setZonaParent(e.target.value)}>
              <option value="">Zona Principal</option>
              {obtenerZonas(ciudadSeleccionada).map((zona, index) => (
                <option key={`${zona.nombre}-${index}`} value={zona.nombre}>
                  {zona.ruta}
                </option>
              ))}
            </select>
          </div>
          <button type="submit" className={styles.btn}>
            Agregar Zona
          </button>
        </form>
      </div>

      <div className={styles.visualizacionArbol}>
        <h3>Estructura de Zonas Verdes</h3>
        <div className={styles.arbol}>{renderArbol(ciudadSeleccionada)}</div>
      </div>
    </div>
  )
}

export default GestionZonasVerdes
