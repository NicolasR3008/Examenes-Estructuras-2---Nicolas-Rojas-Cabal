//Nicolas rojas Cabal- 2226088

"use client"

import { useState, useEffect } from "react"
import { useCiudades } from "../context/CiudadesContext"
import GestionCiudades from "./GestionCiudades"
import VisualizacionGrafo from "./VisualizacionGrafo"
import GestionZonasVerdes from "./GestionZonasVerdes"

const AppContent = () => {
  const [tabActiva, setTabActiva] = useState("ciudades")
  const { grafo, arboles, ciudadSeleccionada } = useCiudades()

  useEffect(() => {
    const guardarEnLocalStorage = () => {
      try {
        const datosParaGuardar = {
          ciudades: grafo.obtenerCiudades(),
          conexiones: grafo.adyacencia,
          ciudadSeleccionada,
        }
        localStorage.setItem("redCiudades", JSON.stringify(datosParaGuardar))
      } catch (error) {
        console.log("Error guardando en localStorage")
      }
    }

    const interval = setInterval(guardarEnLocalStorage, 5000)
    return () => clearInterval(interval)
  }, [grafo, ciudadSeleccionada])

  const renderContenido = () => {
    switch (tabActiva) {
      case "ciudades":
        return <GestionCiudades />
      case "grafo":
        return <VisualizacionGrafo />
      case "zonas":
        return <GestionZonasVerdes />
      default:
        return <GestionCiudades />
    }
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>Red de Ciudades y Zonas Verdes</h1>
        <nav>
          <ul className="menu">
            <li>
              <button
                className={tabActiva === "ciudades" ? "tab-activa" : "tab"}
                onClick={() => setTabActiva("ciudades")}
              >
                Gestión de Ciudades
              </button>
            </li>
            <li>
              <button className={tabActiva === "grafo" ? "tab-activa" : "tab"} onClick={() => setTabActiva("grafo")}>
                Visualización del Grafo
              </button>
            </li>
            <li>
              <button className={tabActiva === "zonas" ? "tab-activa" : "tab"} onClick={() => setTabActiva("zonas")}>
                Gestión de Zonas Verdes
              </button>
            </li>
          </ul>
        </nav>
      </header>

      <main className="app-content">{renderContenido()}</main>
    </div>
  )
}

export default AppContent
