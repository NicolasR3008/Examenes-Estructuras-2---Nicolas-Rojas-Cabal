//Nicolas rojas Cabal- 2226088


import { useCiudades } from "../context/CiudadesContext"

const EstadisticasCiudad = () => {
  const { ciudadSeleccionada, calcularEstadisticas } = useCiudades()

  if (!ciudadSeleccionada) {
    return (
      <div className="seccion">
        <h2>Estadísticas</h2>
        <p>Selecciona una ciudad para ver estadísticas</p>
      </div>
    )
  }

  const { profundidad, totalZonas } = calcularEstadisticas(ciudadSeleccionada)

  return (
    <div className="seccion">
      <h2>Estadísticas de {ciudadSeleccionada}</h2>
      <div style={{ display: "flex", gap: "20px" }}>
        <div
          style={{
            background: "white",
            padding: "15px",
            borderRadius: "8px",
            textAlign: "center",
            flex: 1,
          }}
        >
          <h3>Profundidad</h3>
          <p style={{ fontSize: "2rem", color: "#4caf50", fontWeight: "bold" }}>{profundidad}</p>
        </div>
        <div
          style={{
            background: "white",
            padding: "15px",
            borderRadius: "8px",
            textAlign: "center",
            flex: 1,
          }}
        >
          <h3>Total Zonas</h3>
          <p style={{ fontSize: "2rem", color: "#4caf50", fontWeight: "bold" }}>{totalZonas}</p>
        </div>
      </div>
    </div>
  )
}

export default EstadisticasCiudad
