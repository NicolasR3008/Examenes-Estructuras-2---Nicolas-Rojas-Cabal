//Nicolas rojas Cabal- 2226088


import { configureStore } from "@reduxjs/toolkit"
import ciudadesReducer from "./ciudadesSlice"

export const store = configureStore({
  reducer: {
    ciudades: ciudadesReducer,
  },
})
