//Nicolas rojas Cabal- 2226088


import { createSlice } from "@reduxjs/toolkit"
import Grafo from "../estructuras/Grafo"
import { ArbolZonasVerdes } from "../estructuras/ArbolZonasVerdes"

const cargarDatosIniciales = () => {
  try {
    const datos = localStorage.getItem("redCiudades")
    if (datos) {
      const datosParseados = JSON.parse(datos)
      const grafo = new Grafo()

      datosParseados.ciudades.forEach((ciudad) => {
        grafo.agregarCiudad(ciudad)
      })

      Object.keys(datosParseados.conexiones).forEach((ciudad) => {
        datosParseados.conexiones[ciudad].forEach((conexion) => {
          grafo.conectarCiudades(ciudad, conexion)
        })
      })

      return {
        grafo,
        ciudadSeleccionada: datosParseados.ciudadSeleccionada,
      }
    }
  } catch (error) {
    console.log("Error cargando datos iniciales")
  }
  return null
}

const inicializarGrafo = () => {
  const g = new Grafo()
  g.agregarCiudad("Cali")
  g.agregarCiudad("Bogotá")
  g.agregarCiudad("Medellín")
  g.conectarCiudades("Cali", "Bogotá")
  g.conectarCiudades("Bogotá", "Medellín")
  return g
}

const inicializarArboles = () => {
  const inicial = {}
  inicial["Cali"] = new ArbolZonasVerdes("Parque del Perro")
  inicial["Cali"].raiz.agregarSubzona("Zona Deportiva")
  inicial["Bogotá"] = new ArbolZonasVerdes("Parque Simón Bolívar")
  inicial["Medellín"] = new ArbolZonasVerdes("Jardín Botánico")
  return inicial
}

const datosGuardados = cargarDatosIniciales()

const ciudadesSlice = createSlice({
  name: "ciudades",
  initialState: {
    grafo: datosGuardados?.grafo || inicializarGrafo(),
    arboles: inicializarArboles(),
    ciudadSeleccionada: datosGuardados?.ciudadSeleccionada || null,
  },
  reducers: {
    agregarCiudad: (state, action) => {
      const nombre = action.payload
      state.grafo.agregarCiudad(nombre)
      state.arboles[nombre] = new ArbolZonasVerdes("Parque Principal")
    },
    eliminarCiudad: (state, action) => {
      const nombre = action.payload
      state.grafo.eliminarCiudad(nombre)
      delete state.arboles[nombre]
      if (state.ciudadSeleccionada === nombre) {
        state.ciudadSeleccionada = null
      }
    },
    conectarCiudades: (state, action) => {
      const { ciudad1, ciudad2 } = action.payload
      state.grafo.conectarCiudades(ciudad1, ciudad2)
    },
    desconectarCiudades: (state, action) => {
      const { ciudad1, ciudad2 } = action.payload
      state.grafo.desconectarCiudades(ciudad1, ciudad2)
    },
    seleccionarCiudad: (state, action) => {
      state.ciudadSeleccionada = action.payload
    },
    agregarZonaVerde: (state, action) => {
      const { ciudad, zonaParent, nombreZona } = action.payload
      const arbol = state.arboles[ciudad]
      if (!arbol) return

      if (!zonaParent) {
        arbol.raiz.agregarSubzona(nombreZona)
      } else {
        const nodoParent = arbol.buscarZona(zonaParent)
        if (nodoParent) {
          nodoParent.agregarSubzona(nombreZona)
        }
      }
    },
  },
})

export const {
  agregarCiudad,
  eliminarCiudad,
  conectarCiudades,
  desconectarCiudades,
  seleccionarCiudad,
  agregarZonaVerde,
} = ciudadesSlice.actions

export default ciudadesSlice.reducer

export const guardarEnLocalStorage = (state) => {
  try {
    const datosParaGuardar = {
      ciudades: state.grafo.obtenerCiudades(),
      conexiones: state.grafo.adyacencia,
      ciudadSeleccionada: state.ciudadSeleccionada,
    }
    localStorage.setItem("redCiudades", JSON.stringify(datosParaGuardar))
  } catch (error) {
    console.log("Error guardando en localStorage")
  }
}
