//Nicolas rojas Cabal- 2226088


class Grafo {
  constructor() {
    this.nodos = []
    this.adyacencia = {}
  }

  agregarCiudad(nombre) {
    if (!this.nodos.includes(nombre)) {
      this.nodos.push(nombre)
      this.adyacencia[nombre] = []
    }
  }

  eliminarCiudad(nombre) {
    const indice = this.nodos.indexOf(nombre)
    if (indice !== -1) {
      this.nodos.splice(indice, 1)
      delete this.adyacencia[nombre]

      for (const ciudad in this.adyacencia) {
        const conexiones = this.adyacencia[ciudad]
        const idx = conexiones.indexOf(nombre)
        if (idx !== -1) {
          conexiones.splice(idx, 1)
        }
      }
    }
  }

  conectarCiudades(ciudad1, ciudad2) {
    if (this.nodos.includes(ciudad1) && this.nodos.includes(ciudad2)) {
      if (!this.adyacencia[ciudad1].includes(ciudad2)) {
        this.adyacencia[ciudad1].push(ciudad2)
      }
      if (!this.adyacencia[ciudad2].includes(ciudad1)) {
        this.adyacencia[ciudad2].push(ciudad1)
      }
    }
  }

  desconectarCiudades(ciudad1, ciudad2) {
    if (this.nodos.includes(ciudad1) && this.nodos.includes(ciudad2)) {
      const conexiones1 = this.adyacencia[ciudad1]
      const conexiones2 = this.adyacencia[ciudad2]

      const idx1 = conexiones1.indexOf(ciudad2)
      if (idx1 !== -1) {
        conexiones1.splice(idx1, 1)
      }

      const idx2 = conexiones2.indexOf(ciudad1)
      if (idx2 !== -1) {
        conexiones2.splice(idx2, 1)
      }
    }
  }

  obtenerCiudades() {
    return this.nodos
  }

  obtenerConexiones(ciudad) {
    return this.adyacencia[ciudad] || []
  }
}

export default Grafo
