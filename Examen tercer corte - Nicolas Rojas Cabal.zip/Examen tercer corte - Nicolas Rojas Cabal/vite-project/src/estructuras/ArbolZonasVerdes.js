//Nicolas rojas Cabal- 2226088


class NodoZonaVerde {
  constructor(nombre) {
    this.nombre = nombre
    this.hijos = []
  }

  agregarSubzona(nombre) {
    const nuevaSubzona = new NodoZonaVerde(nombre)
    this.hijos.push(nuevaSubzona)
    return nuevaSubzona
  }
}

class ArbolZonasVerdes {
  constructor(nombrePrincipal) {
    this.raiz = new NodoZonaVerde(nombrePrincipal)
  }

  calcularProfundidad() {
    const calcular = (nodo) => {
      if (nodo.hijos.length === 0) return 0

      let maxProfundidad = 0
      for (const hijo of nodo.hijos) {
        const profundidadHijo = calcular(hijo)
        if (profundidadHijo > maxProfundidad) {
          maxProfundidad = profundidadHijo
        }
      }
      return maxProfundidad + 1
    }

    return calcular(this.raiz) + 1
  }

  contarZonasVerdes() {
    const contar = (nodo) => {
      let contador = 1
      for (const hijo of nodo.hijos) {
        contador += contar(hijo)
      }
      return contador
    }

    return contar(this.raiz)
  }

  buscarZona(nombre, nodoActual = this.raiz) {
    if (nodoActual.nombre === nombre) {
      return nodoActual
    }

    for (const hijo of nodoActual.hijos) {
      const resultado = this.buscarZona(nombre, hijo)
      if (resultado) {
        return resultado
      }
    }

    return null
  }
}

export { NodoZonaVerde, ArbolZonasVerdes }
