//Nicolas rojas Cabal- 2226088


class Grafo {
  constructor() {
    this.nodos = []
    this.adyacencia = {}
  }

  agregarCiudad(nombre) {
    if (!this.nodos.includes(nombre)) {
      this.nodos.push(nombre)
      this.adyacencia[nombre] = []
    }
  }

  eliminarCiudad(nombre) {
    const indice = this.nodos.indexOf(nombre)
    if (indice !== -1) {
      this.nodos.splice(indice, 1)
      delete this.adyacencia[nombre]

      for (const ciudad in this.adyacencia) {
        const conexiones = this.adyacencia[ciudad]
        const idx = conexiones.indexOf(nombre)
        if (idx !== -1) {
          conexiones.splice(idx, 1)
        }
      }
    }
  }

  conectarCiudades(ciudad1, ciudad2) {
    if (this.nodos.includes(ciudad1) && this.nodos.includes(ciudad2)) {
      if (!this.adyacencia[ciudad1].includes(ciudad2)) {
        this.adyacencia[ciudad1].push(ciudad2)
      }
      if (!this.adyacencia[ciudad2].includes(ciudad1)) {
        this.adyacencia[ciudad2].push(ciudad1)
      }
    }
  }

  desconectarCiudades(ciudad1, ciudad2) {
    if (this.nodos.includes(ciudad1) && this.nodos.includes(ciudad2)) {
      const conexiones1 = this.adyacencia[ciudad1]
      const conexiones2 = this.adyacencia[ciudad2]

      const idx1 = conexiones1.indexOf(ciudad2)
      if (idx1 !== -1) {
        conexiones1.splice(idx1, 1)
      }

      const idx2 = conexiones2.indexOf(ciudad1)
      if (idx2 !== -1) {
        conexiones2.splice(idx2, 1)
      }
    }
  }

  obtenerCiudades() {
    return this.nodos
  }

  obtenerConexiones(ciudad) {
    return this.adyacencia[ciudad] || []
  }
}

class NodoZonaVerde {
  constructor(nombre) {
    this.nombre = nombre
    this.hijos = []
  }

  agregarSubzona(nombre) {
    const nuevaSubzona = new NodoZonaVerde(nombre)
    this.hijos.push(nuevaSubzona)
    return nuevaSubzona
  }
}

class ArbolZonasVerdes {
  constructor(nombrePrincipal) {
    this.raiz = new NodoZonaVerde(nombrePrincipal)
  }

  calcularProfundidad() {
    const calcular = (nodo) => {
      if (nodo.hijos.length === 0) return 0

      let maxProfundidad = 0
      for (const hijo of nodo.hijos) {
        const profundidadHijo = calcular(hijo)
        if (profundidadHijo > maxProfundidad) {
          maxProfundidad = profundidadHijo
        }
      }
      return maxProfundidad + 1
    }

    return calcular(this.raiz) + 1
  }

  contarZonasVerdes() {
    const contar = (nodo) => {
      let contador = 1
      for (const hijo of nodo.hijos) {
        contador += contar(hijo)
      }
      return contador
    }

    return contar(this.raiz)
  }

  buscarZona(nombre, nodoActual = this.raiz) {
    if (nodoActual.nombre === nombre) {
      return nodoActual
    }

    for (const hijo of nodoActual.hijos) {
      const resultado = this.buscarZona(nombre, hijo)
      if (resultado) {
        return resultado
      }
    }

    return null
  }
}

export { Grafo, ArbolZonasVerdes }
