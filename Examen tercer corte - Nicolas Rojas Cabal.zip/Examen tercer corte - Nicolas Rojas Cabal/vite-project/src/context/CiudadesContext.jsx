//Nicolas rojas Cabal- 2226088


"use client"

import { createContext, useContext, useReducer, useEffect } from "react"
import Grafo from "../estructuras/Grafo"
import { ArbolZonasVerdes } from "../estructuras/ArbolZonasVerdes"

const CiudadesContext = createContext()

const inicializarGrafo = () => {
  const g = new Grafo()
  g.agregarCiudad("Cali")
  g.agregarCiudad("Bogotá")
  g.agregarCiudad("Medellín")
  g.conectarCiudades("Cali", "Bogotá")
  g.conectarCiudades("Bogotá", "Medellín")
  return g
}

const inicializarArboles = () => {
  const inicial = {}
  inicial["Cali"] = new ArbolZonasVerdes("Parque del Perro")
  inicial["Cali"].raiz.agregarSubzona("Zona Deportiva")
  inicial["Bogotá"] = new ArbolZonasVerdes("Parque Simón Bolívar")
  inicial["Medellín"] = new ArbolZonasVerdes("Jardín Botánico")
  return inicial
}

const ciudadesReducer = (state, action) => {
  switch (action.type) {
    case "AGREGAR_CIUDAD": {
      const nombre = action.payload
      state.grafo.agregarCiudad(nombre)
      state.arboles[nombre] = new ArbolZonasVerdes("Parque Principal")
      return { ...state }
    }
    case "ELIMINAR_CIUDAD": {
      const nombre = action.payload
      state.grafo.eliminarCiudad(nombre)
      delete state.arboles[nombre]
      if (state.ciudadSeleccionada === nombre) {
        state.ciudadSeleccionada = null
      }
      return { ...state }
    }
    case "CONECTAR_CIUDADES": {
      const { ciudad1, ciudad2 } = action.payload
      state.grafo.conectarCiudades(ciudad1, ciudad2)
      return { ...state }
    }
    case "DESCONECTAR_CIUDADES": {
      const { ciudad1, ciudad2 } = action.payload
      state.grafo.desconectarCiudades(ciudad1, ciudad2)
      return { ...state }
    }
    case "SELECCIONAR_CIUDAD": {
      return { ...state, ciudadSeleccionada: action.payload }
    }
    case "AGREGAR_ZONA_PADRE": {
      const { ciudad, nombreZona } = action.payload

      if (!state.arboles[ciudad + "_" + nombreZona]) {
        state.arboles[ciudad + "_" + nombreZona] = new ArbolZonasVerdes(nombreZona)
      }

      return { ...state }
    }
    case "AGREGAR_ZONA_VERDE": {
      const { ciudad, zonaParent, nombreZona } = action.payload

      let arbolEncontrado = null
      let nodoParent = null

      const arbolPrincipal = state.arboles[ciudad]
      if (arbolPrincipal) {
        if (!zonaParent) {
          arbolEncontrado = arbolPrincipal
          nodoParent = arbolPrincipal.raiz
        } else {
          nodoParent = arbolPrincipal.buscarZona(zonaParent)
          if (nodoParent) {
            arbolEncontrado = arbolPrincipal
          }
        }
      }

      if (!arbolEncontrado) {
        for (const clave in state.arboles) {
          if (clave.startsWith(ciudad + "_")) {
            const arbol = state.arboles[clave]
            nodoParent = arbol.buscarZona(zonaParent)
            if (nodoParent) {
              arbolEncontrado = arbol
              break
            }
          }
        }
      }

      if (arbolEncontrado && nodoParent) {
        nodoParent.agregarSubzona(nombreZona)
      }

      return { ...state }
    }
    default:
      return state
  }
}

export const CiudadesProvider = ({ children }) => {
  const [state, dispatch] = useReducer(ciudadesReducer, {
    grafo: inicializarGrafo(),
    arboles: inicializarArboles(),
    ciudadSeleccionada: null,
  })

  useEffect(() => {
    const guardarEnLocalStorage = () => {
      try {
        const datosParaGuardar = {
          ciudades: state.grafo.obtenerCiudades(),
          conexiones: state.grafo.adyacencia,
          ciudadSeleccionada: state.ciudadSeleccionada,
        }
        localStorage.setItem("redCiudades", JSON.stringify(datosParaGuardar))
      } catch (error) {
        console.log("Error guardando en localStorage")
      }
    }

    const interval = setInterval(guardarEnLocalStorage, 5000)
    return () => clearInterval(interval)
  }, [state])

  const agregarCiudad = (nombre) => {
    dispatch({ type: "AGREGAR_CIUDAD", payload: nombre })
  }

  const eliminarCiudad = (nombre) => {
    dispatch({ type: "ELIMINAR_CIUDAD", payload: nombre })
  }

  const conectarCiudades = (ciudad1, ciudad2) => {
    dispatch({ type: "CONECTAR_CIUDADES", payload: { ciudad1, ciudad2 } })
  }

  const desconectarCiudades = (ciudad1, ciudad2) => {
    dispatch({ type: "DESCONECTAR_CIUDADES", payload: { ciudad1, ciudad2 } })
  }

  const seleccionarCiudad = (ciudad) => {
    dispatch({ type: "SELECCIONAR_CIUDAD", payload: ciudad })
  }

  const agregarZonaPadre = (ciudad, nombreZona) => {
    dispatch({ type: "AGREGAR_ZONA_PADRE", payload: { ciudad, nombreZona } })
  }

  const agregarZonaVerde = (ciudad, zonaParent, nombreZona) => {
    dispatch({ type: "AGREGAR_ZONA_VERDE", payload: { ciudad, zonaParent, nombreZona } })
  }

  const calcularEstadisticas = (ciudad) => {
    let profundidadTotal = 0
    let totalZonas = 0

    for (const clave in state.arboles) {
      if (clave === ciudad || clave.startsWith(ciudad + "_")) {
        const arbol = state.arboles[clave]
        const profundidadArbol = arbol.calcularProfundidad()
        const zonasArbol = arbol.contarZonasVerdes()

        if (profundidadArbol > profundidadTotal) {
          profundidadTotal = profundidadArbol
        }
        totalZonas += zonasArbol
      }
    }

    return {
      profundidad: profundidadTotal,
      totalZonas: totalZonas,
    }
  }

  return (
    <CiudadesContext.Provider
      value={{
        grafo: state.grafo,
        arboles: state.arboles,
        ciudadSeleccionada: state.ciudadSeleccionada,
        agregarCiudad,
        eliminarCiudad,
        conectarCiudades,
        desconectarCiudades,
        seleccionarCiudad,
        agregarZonaPadre,
        agregarZonaVerde,
        calcularEstadisticas,
      }}
    >
      {children}
    </CiudadesContext.Provider>
  )
}

export const useCiudades = () => {
  const context = useContext(CiudadesContext)
  if (!context) {
    throw new Error("useCiudades debe usarse dentro de CiudadesProvider")
  }
  return context
}
